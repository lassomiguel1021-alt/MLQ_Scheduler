import csv

class Process:
    def __init__(self, pid, bt, at, q, pr):
        self.pid = pid
        self.bt = bt
        self.at = at
        self.q = q
        self.pr = pr
        self.remaining = bt
        self.start_time = None
        self.completion = None
        self.response = None
        self.wt = None
        self.tat = None

class MLQScheduler:
    def __init__(self, quantum1=3, quantum2=5):
        self.QUANTUMS = {1: quantum1, 2: quantum2}
        self.POLICIES = {1: "RR", 2: "RR", 3: "FCFS"}

    def read_input(self, filename):
        processes = []
        with open(filename, 'r') as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                pid, bt, at, q, pr = line.split(";")
                processes.append(Process(pid.strip(), int(bt), int(at), int(q), int(pr)))
        return processes

    def run_rr(self, queue, time, quantum):
        for p in sorted(queue, key=lambda x: (x.at, -x.pr)):
            if p.remaining > 0 and p.at <= time:
                if p.start_time is None:
                    p.start_time = time
                    p.response = time - p.at
                exec_time = min(p.remaining, quantum)
                p.remaining -= exec_time
                time += exec_time
                if p.remaining == 0:
                    p.completion = time
                return time, True
        return time, False

    def run_fcfs(self, queue, time):
        ready = [p for p in queue if p.remaining > 0 and p.at <= time]
        if not ready:
            return time, False
        p = sorted(ready, key=lambda x: (x.at, -x.pr))[0]
        if p.start_time is None:
            p.start_time = time
            p.response = time - p.at
        time += p.remaining
        p.remaining = 0
        p.completion = time
        return time, True

    def simulate(self, processes):
        time = 0
        finished = 0
        total = len(processes)

        while finished < total:
            did_run = False
            for q in [1, 2, 3]:
                ready = [p for p in processes if p.q == q and p.remaining > 0 and p.at <= time]
                if not ready:
                    continue
                if self.POLICIES[q] == "RR":
                    time, did_run = self.run_rr(ready, time, self.QUANTUMS[q])
                elif self.POLICIES[q] == "FCFS":
                    time, did_run = self.run_fcfs(ready, time)
                if did_run:
                    finished = sum(1 for p in processes if p.remaining == 0)
                    break
            if not did_run:
                next_arrival = min((p.at for p in processes if p.remaining > 0), default=time + 1)
                time = max(time + 1, next_arrival)

        for p in processes:
            p.tat = p.completion - p.at
            p.wt = p.tat - p.bt

        return processes

    def write_output(self, processes, filename):
        with open(filename, "w", newline="") as f:
            writer = csv.writer(f, delimiter=';')
            writer.writerow(["# etiqueta", "BT", "AT", "Q", "Pr", "WT", "CT", "RT", "TAT"])
            for p in processes:
                writer.writerow([p.pid, p.bt, p.at, p.q, p.pr, p.wt, p.completion, p.response, p.tat])
            n = len(processes)
            avg_wt = sum(p.wt for p in processes) / n
            avg_ct = sum(p.completion for p in processes) / n
            avg_rt = sum(p.response for p in processes) / n
            avg_tat = sum(p.tat for p in processes) / n
            f.write(f"\nWT={avg_wt:.2f}; CT={avg_ct:.2f}; RT={avg_rt:.2f}; TAT={avg_tat:.2f}\n")

# ----------- EJECUCIÓN -----------
if __name__ == "__main__":
    scheduler = MLQScheduler()
    files = ["mlq003.txt","mlq004.txt"]
    for file in files:
        processes = scheduler.read_input(file)
        result = scheduler.simulate(processes)
        output_file = file.replace(".txt", "_output.txt")
        scheduler.write_output(result, output_file)
        print(f"Simulación completada para {file}. Resultado en {output_file}")
